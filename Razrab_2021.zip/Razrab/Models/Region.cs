﻿using System;

namespace Razrab.Models
{
    public class Region
    {
        public long Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
    }
}